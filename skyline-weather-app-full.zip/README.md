# 🌤 Skyline — Real-Time Weather App

![Python](https://img.shields.io/badge/Python-3.10%2B-3776AB?style=flat&logo=python&logoColor=white)
![Flask](https://img.shields.io/badge/Flask-3.0-black?style=flat&logo=flask)
![OpenWeatherMap](https://img.shields.io/badge/API-OpenWeatherMap-orange?style=flat)
![License: MIT](https://img.shields.io/badge/License-MIT-green?style=flat)

A sleek, full-stack weather application built with **Python + Flask** that fetches real-time weather data from the OpenWeatherMap API and displays it in a beautiful frosted-glass UI.

> Built as a learning project to practise REST API integration, Flask routing, and frontend–backend communication.

---

## ✨ Features

- 🔍 **Search any city** — get instant weather worldwide
- 🌡️ **Temperature** with feels-like, min & max
- 💧 **Humidity**, 💨 **Wind Speed**, 👁 **Visibility**, 🌡 **Pressure**
- 🖼 **Dynamic weather icons** from OpenWeatherMap
- ⚡ **No page reloads** — JavaScript fetches data in the background
- 📱 **Responsive design** — works on mobile and desktop
- 🎨 **Animated glass-morphism UI** with drifting background blobs

---

## 📸 Screenshot

![App screenshot](https://via.placeholder.com/800x500/0b0f1a/38bdf8?text=Skyline+Weather+App)

---

## 🏗 Project Architecture

```
Browser (HTML + CSS + JS)
        │  POST /weather  {"city": "London"}
        ▼
Flask Web Server (app.py)
        │  requests.get(OpenWeatherMap API)
        ▼
OpenWeatherMap REST API
        │  JSON response with weather data
        ▼
Flask parses & returns clean JSON
        │
        ▼
JavaScript updates the UI card
```

**Key concepts demonstrated:**
- **REST API consumption** — HTTP GET with query parameters
- **Flask routing** — `@app.route` mapping URLs to functions
- **JSON communication** — Frontend and backend speak via `fetch` + `jsonify`
- **Environment variables** — Secrets stay out of code with `python-dotenv`
- **Separation of concerns** — Python handles data, JS handles display

---

## 🗂 Folder Structure

```
weather-app/
├── app.py                  # Flask app — routes and API logic
├── requirements.txt        # Python dependencies
├── .env.example            # Template for your API key
├── .gitignore              # Files Git should ignore
├── templates/
│   └── index.html          # The single HTML page (Jinja2 template)
└── static/
    ├── css/
    │   └── style.css       # All visual styling
    └── js/
        └── app.js          # Frontend interaction logic
```

---

## 🚀 Getting Started

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/weather-app.git
cd weather-app
```

### 2. Create a virtual environment
```bash
python -m venv venv

# Activate it:
source venv/bin/activate        # macOS / Linux
venv\Scripts\activate           # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Get a free API key
1. Sign up at [openweathermap.org](https://openweathermap.org/api)
2. Go to **API keys** in your account dashboard
3. Copy your key (it activates within ~2 hours of signing up)

### 5. Set your API key
```bash
cp .env.example .env
# Open .env and replace 'your_api_key_here' with your real key
```

### 6. Run the app
```bash
python app.py
```
Open your browser and go to **http://127.0.0.1:5000** 🎉

---

## 🛠 Technologies Used

| Technology | Purpose |
|---|---|
| Python 3.10+ | Core backend language |
| Flask 3.0 | Web framework — routing and templates |
| Requests | HTTP library to call the weather API |
| python-dotenv | Load secrets from `.env` file |
| OpenWeatherMap API | Real-time weather data source |
| HTML5 / CSS3 | Frontend structure and styling |
| Vanilla JavaScript | Dynamic UI updates without page reload |

---

## 🔮 Future Features (Roadmap)

- [ ] 📅 **5-day forecast** using the `/forecast` endpoint
- [ ] 🌍 **Geolocation** — auto-detect user's city on page load
- [ ] 🔁 **Unit toggle** — switch between °C and °F
- [ ] 💾 **Search history** — store recent cities in `localStorage`
- [ ] 🗄️ **Database caching** — SQLite to avoid hitting the API on repeat searches
- [ ] 🐳 **Docker** — containerise for one-command deployment
- [ ] ☁️ **Deploy to Render/Railway** — make it publicly accessible
- [ ] 🔔 **Weather alerts** — email/SMS via Twilio or SendGrid

---

## 📄 License

This project is licensed under the [MIT License](LICENSE) — feel free to fork and build on it!

---

## 🙏 Acknowledgements

- Weather data by [OpenWeatherMap](https://openweathermap.org)
- Icons from the OpenWeatherMap icon set
- Inspired by countless weather apps built by the Python community

---

*Made with ❤️ and ☕ by [Your Name](https://github.com/YOUR_USERNAME)*
