// ============================================================
// app.js — Frontend JavaScript for Skyline Weather App
// ============================================================
// This file is responsible for:
//   1. Listening for user interactions (button click, Enter key)
//   2. Sending a POST request to our Flask backend (/weather)
//   3. Receiving the JSON response and populating the HTML card
//   4. Handling loading state and error display
//   5. Managing the °C / °F unit toggle
// ============================================================


// ── DOM REFERENCES ───────────────────────────────────────────
// We grab every HTML element we'll need and store them in variables.
// Calling getElementById once at startup is faster than searching
// the DOM inside every function call.

const cityInput     = document.getElementById("cityInput");
const searchBtn     = document.getElementById("searchBtn");
const btnMetric     = document.getElementById("btnMetric");
const btnImperial   = document.getElementById("btnImperial");

const errorBox      = document.getElementById("errorBox");
const errorText     = document.getElementById("errorText");
const loader        = document.getElementById("loader");
const weatherPanel  = document.getElementById("weatherPanel");

// Current-weather elements
const cityNameEl    = document.getElementById("cityName");
const countryBadge  = document.getElementById("countryBadge");
const coordsEl      = document.getElementById("coords");
const weatherIcon   = document.getElementById("weatherIcon");
const tempValue     = document.getElementById("tempValue");
const weatherDesc   = document.getElementById("weatherDesc");
const feelsLike     = document.getElementById("feelsLike");
const tempMin       = document.getElementById("tempMin");
const tempMax       = document.getElementById("tempMax");
const humidity      = document.getElementById("humidity");
const windSpeed     = document.getElementById("windSpeed");
const windDir       = document.getElementById("windDir");
const visibility    = document.getElementById("visibility");
const pressure      = document.getElementById("pressure");
const sunriseEl     = document.getElementById("sunrise");
const sunsetEl      = document.getElementById("sunset");
const forecastGrid  = document.getElementById("forecastGrid");
const lastUpdated   = document.getElementById("lastUpdated");


// ── APP STATE ────────────────────────────────────────────────
// A simple object that tracks which unit system is currently active.
// 'metric'   → Celsius  + m/s
// 'imperial' → Fahrenheit + mph

let currentUnits = "metric";


// ── EVENT LISTENERS ──────────────────────────────────────────

// Click on the search button → trigger a weather fetch.
searchBtn.addEventListener("click", fetchWeather);

// Pressing Enter inside the text input → same as clicking Search.
cityInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") fetchWeather();
});

// °C button clicked → switch to metric and re-fetch if we have a city.
btnMetric.addEventListener("click", () => {
  setUnit("metric");
});

// °F button clicked → switch to imperial and re-fetch.
btnImperial.addEventListener("click", () => {
  setUnit("imperial");
});


// ── setUnit ──────────────────────────────────────────────────
// Updates the active unit, toggles button styles, and re-fetches
// weather in the new unit if a city is already displayed.

function setUnit(unit) {
  if (unit === currentUnits) return;  // already selected — do nothing

  currentUnits = unit;

  // Toggle the 'active' CSS class between the two buttons.
  // The 'active' class applies the gradient background via CSS.
  btnMetric.classList.toggle("active",   unit === "metric");
  btnImperial.classList.toggle("active", unit === "imperial");

  // If the panel is visible (a city was already searched), re-fetch
  // so the user sees updated units without having to press Search again.
  if (!weatherPanel.hidden) {
    fetchWeather();
  }
}


// ── fetchWeather ─────────────────────────────────────────────
// The main function. Reads the city input, calls the Flask backend,
// and renders the result (or shows an error).
//
// 'async' makes this function return a Promise and allows us to
// use 'await' inside it, which pauses execution until a Promise
// resolves — without blocking the browser UI.

async function fetchWeather() {
  const city = cityInput.value.trim();

  if (!city) {
    showError("Please type a city name first.");
    return;   // Stop execution here — nothing to search for.
  }

  // Show the spinner; hide any stale data or error messages.
  showLoader(true);
  hideError();
  hidePanel();

  try {
    // ── POST request to our Flask route ────────────────────
    // 'fetch' is the modern browser API for HTTP requests.
    // It returns a Promise that resolves with a Response object.

    const response = await fetch("/weather", {
      method: "POST",

      headers: {
        // Tell Flask the request body is JSON, not a form submission.
        "Content-Type": "application/json",
      },

      // JSON.stringify converts: { city: "Tokyo", units: "metric" }
      // into the string:         '{"city":"Tokyo","units":"metric"}'
      body: JSON.stringify({
        city:  city,
        units: currentUnits,
      }),
    });

    // ── Parse the response body ─────────────────────────────
    // response.json() reads the body stream and parses it as JSON.
    // It also returns a Promise, so we await it.
    const data = await response.json();

    if (data.success) {
      renderWeather(data);   // Fill in the weather card.
    } else {
      // Flask returned { success: false, error: "..." }
      showError(data.error);
    }

  } catch (err) {
    // This catch block runs if:
    //   - fetch() itself throws (e.g. no internet connection)
    //   - response.json() throws (malformed response body)
    showError("Network error. Make sure the Flask server is running.");
    console.error("fetchWeather error:", err);

  } finally {
    // 'finally' always runs — whether the try succeeded or the
    // catch fired. We always want to hide the spinner.
    showLoader(false);
  }
}


// ── renderWeather ─────────────────────────────────────────────
// Takes the data object from Flask and populates all HTML elements.
// Called only when data.success === true.

function renderWeather(d) {

  // ── Location info ─────────────────────────────────────────
  cityNameEl.textContent    = d.city;
  countryBadge.textContent  = d.country;
  coordsEl.textContent      = `${d.lat.toFixed(2)}°N, ${d.lon.toFixed(2)}°E`;

  // ── Weather icon ──────────────────────────────────────────
  // OpenWeatherMap icons follow the URL pattern:
  //   https://openweathermap.org/img/wn/{icon_code}@2x.png
  // '@2x' requests a 100×100 px image instead of the default 50×50.
  weatherIcon.src = `https://openweathermap.org/img/wn/${d.icon}@2x.png`;
  weatherIcon.alt = d.description;   // accessibility: describes the image

  // ── Temperature ───────────────────────────────────────────
  // d.temp_unit is "°C" or "°F" depending on units sent to Flask.
  tempValue.textContent   = `${d.temp}${d.temp_unit}`;
  weatherDesc.textContent = d.description;
  feelsLike.textContent   = `Feels like ${d.feels_like}${d.temp_unit}`;
  tempMin.textContent     = `↓ ${d.temp_min}${d.temp_unit}`;
  tempMax.textContent     = `↑ ${d.temp_max}${d.temp_unit}`;

  // ── Stat cards ────────────────────────────────────────────
  humidity.textContent    = `${d.humidity}%`;
  windSpeed.textContent   = `${d.wind_speed} ${d.wind_unit}`;

  // Wind direction e.g. "NNE" or "SW"
  windDir.textContent     = d.wind_direction
    ? `Direction: ${d.wind_direction}`
    : "";

  visibility.textContent  = `${d.visibility} km`;
  pressure.textContent    = `${d.pressure} hPa`;

  // ── Sunrise / Sunset ──────────────────────────────────────
  // The API returns Unix timestamps (seconds since Jan 1 1970 UTC).
  // Multiply by 1000 for milliseconds (JS Date uses ms).
  sunriseEl.textContent = formatTime(d.sunrise * 1000);
  sunsetEl.textContent  = formatTime(d.sunset  * 1000);

  // ── 5-Day Forecast ────────────────────────────────────────
  renderForecast(d.forecast || []);

  // ── Timestamp ─────────────────────────────────────────────
  lastUpdated.textContent = `Updated at ${new Date().toLocaleTimeString()}`;

  // ── Show the panel ────────────────────────────────────────
  weatherPanel.hidden = false;

  // Re-trigger the CSS entrance animation so it plays on every search.
  // We must force a browser reflow between removing and re-adding the
  // animation — accessing offsetHeight does that.
  weatherPanel.style.animation = "none";
  void weatherPanel.offsetHeight;   // reflow trigger
  weatherPanel.style.animation = "";
}


// ── renderForecast ────────────────────────────────────────────
// Builds the forecast day cards and inserts them into #forecastGrid.

function renderForecast(days) {
  // Clear any previously rendered forecast cards.
  forecastGrid.innerHTML = "";

  if (!days.length) {
    // If no forecast data came back, hide the whole section quietly.
    forecastGrid.closest(".forecast-section").style.display = "none";
    return;
  }

  forecastGrid.closest(".forecast-section").style.display = "";

  days.forEach((day) => {
    // Create a new <div> element for each day.
    const card = document.createElement("div");
    card.className = "forecast-day";

    // Format "2024-06-15" → "Sat", "Sun", etc.
    // The Date constructor parses ISO strings, but adding 'T12:00:00'
    // avoids timezone edge cases where the date shifts by one day.
    const dateObj  = new Date(day.date + "T12:00:00");
    const dayName  = dateObj.toLocaleDateString("en-US", { weekday: "short" });

    // Build the inner HTML for this card.
    // Template literals (backtick strings) let us embed ${variables}.
    card.innerHTML = `
      <div class="forecast-day-name">${dayName}</div>
      <img
        class="forecast-icon"
        src="https://openweathermap.org/img/wn/${day.icon}.png"
        alt="${day.description}"
        loading="lazy"
      />
      <div class="forecast-temp">${day.temp}°</div>
      <div class="forecast-desc">${day.description}</div>
    `;

    // Append the card to the grid container.
    forecastGrid.appendChild(card);
  });
}


// ── formatTime ───────────────────────────────────────────────
// Converts a Unix timestamp (milliseconds) into a human-readable
// time string using the browser's locale (e.g. "6:24 AM").

function formatTime(ms) {
  return new Date(ms).toLocaleTimeString("en-US", {
    hour:   "2-digit",
    minute: "2-digit",
  });
}


// ── UI STATE HELPERS ──────────────────────────────────────────
// Small utility functions that show/hide elements.
// Using the 'hidden' HTML attribute is more semantic than toggling
// a 'display' CSS property directly.

function showLoader(visible) {
  loader.hidden = !visible;
}

function showError(message) {
  errorText.textContent = message;
  errorBox.hidden = false;
}

function hideError() {
  errorBox.hidden = true;
  errorText.textContent = "";
}

function hidePanel() {
  weatherPanel.hidden = true;
}
