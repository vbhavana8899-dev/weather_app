# ============================================================
# app.py — Main Flask Application Entry Point
# ============================================================
# This is the file you run: `python app.py`
# Flask reads this file, registers all routes, and starts the
# development web server on http://127.0.0.1:5000
# ============================================================

import os                          # Read environment variables
import requests                    # Make HTTP calls to external APIs
from flask import (
    Flask,                         # The core Flask class
    render_template,               # Render HTML templates with Jinja2
    request,                       # Read incoming HTTP request data
    jsonify                        # Convert Python dicts → JSON responses
)
from dotenv import load_dotenv     # Load secrets from a .env file


# ── Load environment variables ──────────────────────────────
# python-dotenv reads the .env file and injects each line as an
# environment variable, so os.getenv() can find them below.
load_dotenv()


# ── Create the Flask application instance ───────────────────
# '__name__' is a Python built-in that equals the module name.
# Flask uses it to locate templates/ and static/ folders.
app = Flask(__name__)


# ── Configuration constants ──────────────────────────────────
API_KEY  = os.getenv("OPENWEATHER_API_KEY")           # Your secret key
BASE_URL = "https://api.openweathermap.org/data/2.5"  # API base path


# ============================================================
# HELPER: get_current_weather
# ============================================================
def get_current_weather(city: str, units: str = "metric") -> dict:
    """
    Fetch current weather for a city from OpenWeatherMap.

    Parameters
    ----------
    city  : str  — City name entered by the user, e.g. "London"
    units : str  — "metric" (°C, m/s) or "imperial" (°F, mph)

    Returns
    -------
    dict  — Structured weather data on success, error info on failure.
    """

    # Build query parameters the API expects.
    params = {
        "q":     city,     # City name
        "appid": API_KEY,  # Your API key for authentication
        "units": units,    # Unit system for temperature & wind
    }

    # Make the GET request. 'timeout=10' means: if the API doesn't
    # respond within 10 seconds, raise a Timeout exception.
    response = requests.get(
        f"{BASE_URL}/weather",
        params=params,
        timeout=10
    )

    # ── Handle HTTP response codes ───────────────────────────
    if response.status_code == 200:
        # Success — parse the JSON body into a Python dict.
        d = response.json()

        # Wind data sometimes lacks a 'gust' key, so use .get()
        # with a default of 0 to avoid a KeyError crash.
        wind = d.get("wind", {})

        # Build and return a clean, flat dictionary with only
        # the fields our frontend needs. This hides the raw API
        # structure from the rest of our code.
        return {
            "success":     True,
            "city":        d["name"],
            "country":     d["sys"]["country"],
            "lat":         d["coord"]["lat"],
            "lon":         d["coord"]["lon"],

            # 'weather' is a list; index [0] is the primary condition.
            "condition":   d["weather"][0]["main"],
            "description": d["weather"][0]["description"].title(),
            "icon":        d["weather"][0]["icon"],   # e.g. "10d"

            # 'main' block holds temperature and pressure readings.
            "temp":        round(d["main"]["temp"]),
            "feels_like":  round(d["main"]["feels_like"]),
            "temp_min":    round(d["main"]["temp_min"]),
            "temp_max":    round(d["main"]["temp_max"]),
            "humidity":    d["main"]["humidity"],     # percent (0-100)
            "pressure":    d["main"]["pressure"],     # hPa

            # Wind data
            "wind_speed":  wind.get("speed", 0),     # m/s or mph
            "wind_gust":   wind.get("gust", 0),      # peak gust speed
            "wind_deg":    wind.get("deg", 0),        # direction in degrees

            # Visibility is in metres; divide by 1000 for km.
            # .get() with default 10000 if the field is absent.
            "visibility":  d.get("visibility", 10000) // 1000,

            # Cloud cover percentage (0-100)
            "clouds":      d["clouds"]["all"],

            # Sunrise and sunset as Unix timestamps (seconds since epoch).
            # JavaScript can convert these to local times.
            "sunrise":     d["sys"]["sunrise"],
            "sunset":      d["sys"]["sunset"],

            # Which unit system was used, so the frontend can label correctly.
            "units":       units,
        }

    elif response.status_code == 404:
        # City name not found in the API's database.
        return {
            "success": False,
            "error": f"City '{city}' not found. Please check the spelling."
        }

    elif response.status_code == 401:
        # API key is wrong, expired, or not yet activated.
        # Keys take up to 2 hours to activate after first sign-up.
        return {
            "success": False,
            "error": "Invalid API key. Double-check your .env file."
        }

    elif response.status_code == 429:
        # Free tier allows 60 calls/minute. We exceeded that.
        return {
            "success": False,
            "error": "Too many requests. Please wait a moment and try again."
        }

    else:
        # Any other unexpected HTTP status code.
        return {
            "success": False,
            "error": f"Unexpected API error (HTTP {response.status_code})."
        }


# ============================================================
# HELPER: get_forecast
# ============================================================
def get_forecast(city: str, units: str = "metric") -> dict:
    """
    Fetch a 5-day / 3-hour forecast from OpenWeatherMap.

    OpenWeatherMap's free forecast endpoint returns 40 data points,
    one every 3 hours for 5 days. We group them by date and take
    the midday reading (12:00) to represent each day.

    Parameters
    ----------
    city  : str — City name
    units : str — "metric" or "imperial"

    Returns
    -------
    dict  — List of daily forecasts, or error info.
    """

    params = {
        "q":     city,
        "appid": API_KEY,
        "units": units,
        "cnt":   40,    # Maximum readings (5 days × 8 per day)
    }

    response = requests.get(
        f"{BASE_URL}/forecast",
        params=params,
        timeout=10
    )

    if response.status_code != 200:
        return {"success": False, "error": "Could not fetch forecast data."}

    data = response.json()

    # ── Group forecast readings by date ──────────────────────
    # 'list' is the key in the API response that holds all readings.
    daily = {}  # { "2024-06-15": [ reading1, reading2, ... ], ... }

    for reading in data["list"]:
        # 'dt_txt' looks like "2024-06-15 12:00:00"
        # Split on the space and take the date part only.
        date = reading["dt_txt"].split(" ")[0]

        # setdefault initialises the key with [] if not already present.
        daily.setdefault(date, []).append(reading)

    # ── Pick one representative reading per day ───────────────
    # We prefer the 12:00:00 reading (midday) as most representative.
    # If 12:00 isn't available, we fall back to the first reading.
    forecasts = []

    for date, readings in sorted(daily.items()):   # sorted by date
        # Try to find the midday reading first.
        midday = next(
            (r for r in readings if "12:00:00" in r["dt_txt"]),
            readings[0]   # fallback: first available reading
        )

        forecasts.append({
            "date":        date,
            "temp":        round(midday["main"]["temp"]),
            "temp_min":    round(midday["main"]["temp_min"]),
            "temp_max":    round(midday["main"]["temp_max"]),
            "description": midday["weather"][0]["description"].title(),
            "icon":        midday["weather"][0]["icon"],
            "humidity":    midday["main"]["humidity"],
            "wind_speed":  midday["wind"]["speed"],
        })

    # Return only 5 days (skip today if we already have current weather).
    return {"success": True, "forecast": forecasts[:5]}


# ============================================================
# HELPER: wind_direction
# ============================================================
def wind_direction(degrees: int) -> str:
    """
    Convert a wind bearing in degrees (0-360) to a compass label.

    0° / 360° = North, 90° = East, 180° = South, 270° = West.

    Example: wind_direction(225) → "SW"
    """
    # 16-point compass rose. Each sector spans 22.5°.
    # We divide degrees by 22.5 and round to get the index.
    directions = [
        "N", "NNE", "NE", "ENE",
        "E", "ESE", "SE", "SSE",
        "S", "SSW", "SW", "WSW",
        "W", "WNW", "NW", "NNW"
    ]
    # The modulo 16 ensures we wrap around at 360°.
    index = round(degrees / 22.5) % 16
    return directions[index]


# ============================================================
# ROUTE: GET /
# ============================================================
@app.route("/")
def index():
    """
    Home page. Renders the main HTML template.

    Flask looks for 'index.html' inside the /templates folder.
    render_template uses Jinja2 to process the file and return HTML.
    """
    return render_template("index.html")


# ============================================================
# ROUTE: POST /weather
# ============================================================
@app.route("/weather", methods=["POST"])
def weather():
    """
    Weather data endpoint.

    Expects a JSON body: { "city": "London", "units": "metric" }
    Returns JSON with current weather + 5-day forecast combined.

    We use POST (not GET) because:
    - POST bodies don't appear in browser history / server logs
    - It's a better semantic fit for "please process this input"
    """

    # Read and parse the JSON body from the request.
    body = request.get_json(silent=True)

    # 'silent=True' returns None instead of raising an error if
    # the body isn't valid JSON.
    if not body:
        return jsonify({"success": False, "error": "Invalid request body."})

    # Extract fields with defaults.
    city  = body.get("city", "").strip()
    units = body.get("units", "metric")   # default to Celsius

    # Validate that the city field isn't empty.
    if not city:
        return jsonify({"success": False, "error": "Please enter a city name."})

    # Validate the units parameter so no arbitrary strings reach the API.
    if units not in ("metric", "imperial"):
        units = "metric"

    # ── Fetch current weather ─────────────────────────────────
    current = get_current_weather(city, units)

    if not current["success"]:
        # Pass the error message straight back to the frontend.
        return jsonify(current)

    # ── Fetch 5-day forecast ──────────────────────────────────
    # We use the validated city name returned by the API (d["name"])
    # rather than the raw user input — handles case/spelling differences.
    forecast_data = get_forecast(current["city"], units)

    # Merge forecast into the current weather dict (if successful).
    if forecast_data["success"]:
        current["forecast"] = forecast_data["forecast"]
    else:
        current["forecast"] = []   # Return empty list on forecast failure

    # ── Add computed extras ───────────────────────────────────
    # Convert wind degrees to a human-readable compass direction.
    current["wind_direction"] = wind_direction(current["wind_deg"])

    # Determine the temperature unit symbol for display.
    current["temp_unit"] = "°C" if units == "metric" else "°F"

    # Wind speed unit label.
    current["wind_unit"] = "m/s" if units == "metric" else "mph"

    return jsonify(current)


# ============================================================
# ROUTE: GET /health
# ============================================================
@app.route("/health")
def health():
    """
    Simple health-check endpoint.

    Useful for deployment platforms (e.g. Render, Railway) to verify
    the server is alive. Returns HTTP 200 with a JSON status message.
    """
    return jsonify({"status": "ok", "app": "Skyline Weather"})


# ============================================================
# ENTRY POINT
# ============================================================
if __name__ == "__main__":
    # This block only executes when you run `python app.py` directly.
    # It does NOT run when deployed via gunicorn or uwsgi.
    #
    # debug=True  → auto-reload on file changes; shows traceback in browser.
    # NEVER use debug=True in production — it exposes server internals.
    app.run(debug=True, host="0.0.0.0", port=5000)
